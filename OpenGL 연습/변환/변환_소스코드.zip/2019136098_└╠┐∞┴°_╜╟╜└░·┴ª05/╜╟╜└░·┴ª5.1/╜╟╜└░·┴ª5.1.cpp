#pragma once
#include <stdio.h>
#include <memory.h>
#include <gl/glut.h>

#define _USE_MATH_DEFINES
#include <math.h>
#define SIN(x) sin(x*M_PI / 180.)
#define COS(x) cos(x*M_PI / 180.)

inline void glkMatSet(double* m,
	double m00, double m01, double m02, double m03,
	double m10, double m11, double m12, double m13,
	double m20, double m21, double m22, double m23,
	double m30, double m31, double m32, double m33)
{
	double mat[16] = { m00,}
	memcpy(m, mat, sizeof(double) * 16);
}