#include "Robot.h"
#include <gl/glut.h>
#include "glk.h"

static Robot robot;
static bool bCamRot = false;
static bool bRobotRun = false;
static double tSpeed = 100;

static float RotX = 0.0f;
static float RotY = 0.0f;

void display() {
	glClearColor(0.99, 0.97, 0.97, 1.0);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	gluLookAt(0, 0, 0, SIN(RotY), 0.01 * RotX, COS(RotY), 0, 1, 0);

	robot.draw();
	glutSwapBuffers();
	glFlush();
}

void timerCallback(int tId) {
	if (bCamRot && tId == 1) {
		RotY += 5;
		if (RotY > 360) {
			RotY = 0;
		}
		glutTimerFunc(50, timerCallback, 1);
	}

	if (bRobotRun && tId == 2) {
		robot.run();
		glutTimerFunc((int)(tSpeed), timerCallback, 2);
	}
	glutPostRedisplay();
}

void keyboard(unsigned char key, int x, int y) {
	if (key == 'i') {
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		RotX = RotY = 0.0f;
	}
	else if (key == 'v') {
		bCamRot = !bCamRot;
		glutTimerFunc(100, timerCallback, 1);
	}
	else if (key == 'r') {
		bRobotRun = !bRobotRun;
		if (bRobotRun)
			glutTimerFunc(40, timerCallback, 2);
		else robot.stop();
	}
	else if (key == 'f' || key == 'F') {
		tSpeed *= ((key == 'f') ? 0.9 : 1.1);
	}
	else if (key == 'w') {
		glPolygonMode(GL_FRONT, GL_LINE);
		glPolygonMode(GL_BACK, GL_POINT);
	}
	else if (key == 's') {
		glPolygonMode(GL_FRONT, GL_FILL);
		glPolygonMode(GL_BACK, GL_LINE);
	}
	else if (key == 'z' || key == 'Z') {
		robot.resize(key == 'z');
	}
	else if (key == 'q')
		exit(0);
	glutPostRedisplay();
}

static int PrevX, PrevY;
void mouseClick(int button, int state, int x, int y) {
	if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN) {
		PrevX = x;
		PrevY = y;
	}
}
void mouseMotion(GLint x, GLint y) {
	glMatrixMode(GL_MODELVIEW);
	glRotated(x - PrevX, 0, 1, 0);
	glRotated(y - PrevY, 1, 0, 0);
	PrevX = x;
	PrevY = y;
	glutPostRedisplay();
}

void initRendering() {
	GLfloat light_specular[] = { 0.8, 0.5, 0.8, 1.0 };
	GLfloat light_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
	GLfloat light_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
	GLfloat light_position[] = { 0.f, -2.5f, 2.5f, 0.0f };
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);

	GLfloat mat_specular[] = { 0.5, 1.0, 0.5, 1.0 };
	GLfloat mat_shininess[] = { 70.0 };
	GLfloat mat_color[] = { 0.5, 0.5, 0.5, 1.0 };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, mat_color);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, mat_color);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	// glEnable(GL_NORMALIZE);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
}
int main(int argc, char** argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE);
	glutInitWindowSize(600, 600);
	glutCreateWindow("RobotWorld");

	glutDisplayFunc(display);
	glutKeyboardFunc(keyboard);
	glutMouseFunc(mouseClick);
	glutMotionFunc(mouseMotion);

	initRendering();
	keyboard('s', 0, 0);
	keyboard('1', 0, 0);
	// glfrontFace(GL_CW);

	glutMainLoop();
	return 0;
}