#include "glk.h"
#include <string.h>
void glkString(const char* s) {
	unsigned int i;
	for (i = 0; i < strlen(s); i++)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, s[i]);
}
void glkSetColor(float r, float g, float b, float a) {
	float color[4] = { r,g,b,a };
	glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, color);
	glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, color);
}
void glkDrawCoord(double len)
{
	glDisable(GL_LIGHTING);
	glColor3f(1.0f, 0, 0);
	glkLine(0, 0, 0, len, 0, 0);
	glRasterPos3f(len, 0, 0);
	glkString("x");

	glColor3f(0, 1.0f, 0);
	glkLine(0, 0, 0, 0, len, 0);
	glRasterPos3f(0, len, 0);
	glkString("y");

	glColor3f(0, 0, 1.0f);
	glkLine(0, 0, 0, 0, 0, -len);
	glRasterPos3f(0, 0, -len);
	glkString("z");
	glEnable(GL_LIGHTING);
}

void glkMessage(int line_no, const char* message)
{
	printf("Line %d: %s\n", line_no, message);
}